package com.example.demo.repository;

import com.example.demo.model.Advice;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by fang on 2017/11/12.
 */
public interface AdviceRepository extends CrudRepository<Advice,Integer> {
}
